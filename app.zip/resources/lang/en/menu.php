<?php
    return [
        'servicio' => 'Our Service',
        'conocenos' => 'About Us',
        'contactanos' => 'Contact Us',
        'hora' => 'Book our service',
        'esp' => 'Spanish',
        'eng' => 'English'
    ];
