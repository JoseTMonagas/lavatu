<?php

return [
    'banner' => 'That one that you like so much, use it whenever you want.',
    'servicios' => 'Our Services',
    'elegirnos' => 'Why choose us',
    'lavado' => 'Washing and drying self-service',
    'secado' => 'Drying-only self-service',
    'encargo' => 'Order service',
    'reserva' => 'Reserve now',
    '1' => 'Simple and quick',
    '2' => 'Goodbye humidity',
    '3' => 'Close to you',
    '4' => 'Do it yourself',
    '5' => 'More convenient',
    '6' => 'Ideal for hostels',
    'suscribete' => 'Subscribe and find out about our offers and promotions',
    'btn-reglamento' => 'Use Regulation',
    'btn-lavadora' => 'Good care of washing machines',
    'btn-secadora' => 'Good care of drying machines',
    'btn-ropa' => 'Tips for your laundry'
];
