<?php
return [
    'email' => 'E-mail:',
    'asunto' => 'Subject:',
    'message' => 'Your Message:',
    'enviar' => 'Send'
];
