<?php
return [
    'email' => 'E-mail:',
    'asunto' => 'Asunto:',
    'message' => 'Tu Mensaje:',
    'enviar' => 'Enviar'
];
