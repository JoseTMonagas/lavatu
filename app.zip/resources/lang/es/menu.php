<?php
    return [
        'servicio' => 'Nuestro Servicio',
        'conocenos' => 'Conocenos',
        'contactanos' => 'Contactanos',
        'hora' => 'Reserva tu hora',
        'esp' => 'Español',
        'eng' => 'Ingles'
    ];
