<?php

return [
    'banner' => 'Esa tenida que tanto te gusta, úsala cuando quieras.',
    'servicios' => 'Nuestros Servicios',
    'elegirnos' => 'Por qué elegirnos',
    'lavado' => 'Autoservicio de lavado y secado',
    'secado' => 'Autoservicio secado',
    'encargo' => 'Servicio de encargo',
    'reserva' => 'Reservar tu hora',
    '1' => 'Simple y rápido',
    '2' => 'Adiós humedad',
    '3' => 'Cerca de todo',
    '4' => 'Házlo tu mismo',
    '5' => 'Más conveniente',
    '6' => 'Ideal para hostales',
    'suscribete' => 'Suscribete y entérate de nuestras ofertas y promociones.',
    'btn-reglamento' => 'Reglamento de Uso',
    'btn-lavadora' => 'Buen uso de las lavadoras',
    'btn-secadora' => 'Buen uso de las secadoras',
    'btn-ropa' => 'Tips para cuidar tu ropa'
];
