@extends('layouts.app')

@section('content')
    @include("partials.content")
@endsection
