<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Suscriptor extends Model
{
    protected $fillable = ['nombre', 'telefono', 'correo'];
}
